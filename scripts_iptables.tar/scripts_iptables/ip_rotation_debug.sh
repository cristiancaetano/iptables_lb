#!/bin/bash

# Script para debugar problemas de rotação de IPs
# Analisa as regras e identifica conflitos

INTERFACE="eth0"

echo "=== Debug de Rotação de IPs ==="
echo "Interface: $INTERFACE"
echo "Data: $(date)"
echo

# Verificar chains
echo "1. Verificando chains existentes:"
echo "   - Chain IP_ROTATION_MARK:"
if iptables -t mangle -L IP_ROTATION_MARK -n >/dev/null 2>&1; then
    echo "     ✓ Existe"
    MARK_REFS=$(iptables -t mangle -L IP_ROTATION_MARK -n | grep -o "[0-9]* references" | cut -d' ' -f1)
    echo "     Referências: $MARK_REFS"
else
    echo "     ✗ Não existe"
fi

echo "   - Chain IP_ROTATION:"
if iptables -t nat -L IP_ROTATION -n >/dev/null 2>&1; then
    echo "     ✓ Existe"
    NAT_REFS=$(iptables -t nat -L IP_ROTATION -n | grep -o "[0-9]* references" | cut -d' ' -f1)
    echo "     Referências: $NAT_REFS"
else
    echo "     ✗ Não existe"
fi

echo
echo "2. Analisando chain OUTPUT (mangle):"
iptables -t mangle -L OUTPUT -n --line-numbers | grep -E "(IP_ROTATION_MARK|^[0-9])" | head -5

echo
echo "3. Analisando chain POSTROUTING (nat):"
iptables -t nat -L POSTROUTING -n --line-numbers | head -10

echo
echo "4. Verificando regras MASQUERADE na interface $INTERFACE:"
MASQ_RULES=$(iptables -t nat -L POSTROUTING -n --line-numbers | grep -E "$INTERFACE.*MASQUERADE")
if [ -n "$MASQ_RULES" ]; then
    echo "   ⚠️  Regras MASQUERADE encontradas:"
    echo "$MASQ_RULES" | sed 's/^/     /'
else
    echo "   ✓ Nenhuma regra MASQUERADE conflitante"
fi

echo
echo "5. Testando marcação de pacotes:"
echo "   Enviando pacote de teste..."
ping -c 1 -W 1 8.8.8.8 >/dev/null 2>&1

echo "   Contadores de marcação:"
iptables -t mangle -L IP_ROTATION_MARK -n -v | grep -E "(pkts|MARK)" | head -5

echo
echo "6. Testando SNAT:"
echo "   Contadores de SNAT:"
iptables -t nat -L IP_ROTATION -n -v | grep -E "(pkts|SNAT)" | head -5

echo
echo "7. Diagnóstico de problemas:"

# Problema 1: Chain não referenciada
if [ "$MARK_REFS" = "0" ]; then
    echo "   ❌ PROBLEMA: Chain IP_ROTATION_MARK não está sendo chamada"
    echo "      Solução: Verificar se a regra OUTPUT foi criada corretamente"
fi

# Problema 2: MASQUERADE conflitante
if [ -n "$MASQ_RULES" ]; then
    echo "   ❌ PROBLEMA: Regras MASQUERADE conflitantes encontradas"
    echo "      Solução: Remover ou mover regras MASQUERADE para depois das nossas"
fi

# Problema 3: Regras fora de ordem
FIRST_RULE=$(iptables -t nat -L POSTROUTING -n --line-numbers | grep -m1 "$INTERFACE" | cut -d' ' -f1)
if [ "$FIRST_RULE" != "1" ] && [ -n "$FIRST_RULE" ]; then
    echo "   ❌ PROBLEMA: Nossa regra não é a primeira na chain POSTROUTING"
    echo "      Posição atual: $FIRST_RULE"
    echo "      Solução: Usar -I (insert) ao invés de -A (append)"
fi

echo
echo "8. Comando para aplicar correções:"
echo "   ./fix_ip_rotation.sh"

echo
echo "9. Comando para testar distribuição:"
echo "   ./test_ip_distribution.sh test 20"
if [ ! -f "./ip_rotation_script.sh" ]; then
    echo "❌ ERRO: Script principal não encontrado!"
    exit 1
fi

# 2. Verificar se é executado como root
if [ "$EUID" -ne 0 ]; then
    echo "❌ ERRO: Execute como root (sudo)"
    exit 1
fi

# 3. Verificar dependências
echo "1. Verificando dependências..."
for cmd in iptables ip ping bc; do
    if command -v "$cmd" &> /dev/null; then
        echo "   ✓ $cmd encontrado"
    else
        echo "   ❌ $cmd NÃO encontrado"
    fi
done
echo

# 4. Verificar IP forwarding
echo "2. Verificando IP forwarding..."
forward_status=$(cat /proc/sys/net/ipv4/ip_forward)
if [ "$forward_status" = "1" ]; then
    echo "   ✓ IP forwarding habilitado"
else
    echo "   ❌ IP forwarding desabilitado"
    echo "   Habilitando IP forwarding..."
    echo 1 > /proc/sys/net/ipv4/ip_forward
    echo "   ✓ IP forwarding habilitado"
fi
echo

# 5. Verificar interface de rede
echo "3. Verificando interface de rede..."
INTERFACE="eth0"  # Ajuste conforme necessário
if ip link show "$INTERFACE" &> /dev/null; then
    echo "   ✓ Interface $INTERFACE encontrada"
    echo "   Status:"
    ip addr show "$INTERFACE" | grep -E "inet|UP|DOWN" | sed 's/^/     /'
else
    echo "   ❌ Interface $INTERFACE não encontrada"
    echo "   Interfaces disponíveis:"
    ip link show | grep -E "^[0-9]+" | sed 's/^/     /'
fi
echo

# 6. Verificar conectividade básica
echo "4. Verificando conectividade básica..."
if ping -c 1 -W 5 8.8.8.8 &> /dev/null; then
    echo "   ✓ Conectividade para 8.8.8.8 OK"
else
    echo "   ❌ Falha na conectividade para 8.8.8.8"
fi

if ping -c 1 -W 5 127.0.0.1 &> /dev/null; then
    echo "   ✓ Conectividade localhost OK"
else
    echo "   ❌ Falha na conectividade localhost"
fi
echo

# 7. Verificar regras de iptables
echo "5. Verificando regras de iptables..."
echo "   Políticas atuais:"
iptables -L | grep "policy" | sed 's/^/     /'

echo "   Chains personalizadas:"
if iptables -t nat -L IP_ROTATION &> /dev/null; then
    echo "     ✓ Chain IP_ROTATION (NAT) encontrada"
else
    echo "     ❌ Chain IP_ROTATION (NAT) não encontrada"
fi

if iptables -t mangle -L IP_ROTATION_MARK &> /dev/null; then
    echo "     ✓ Chain IP_ROTATION_MARK (MANGLE) encontrada"
else
    echo "     ❌ Chain IP_ROTATION_MARK (MANGLE) não encontrada"
fi
echo

# 8. Sugestões de correção
echo "6. Sugestões de correção:"
echo

echo "   Para resolver problemas de conectividade:"
echo "   1. Pare a rotação: ./ip_rotation_script.sh stop"
echo "   2. Limpe todas as regras: iptables -F && iptables -t nat -F && iptables -t mangle -F"
echo "   3. Defina políticas permissivas: iptables -P INPUT ACCEPT && iptables -P FORWARD ACCEPT && iptables -P OUTPUT ACCEPT"
echo "   4. Habilite forwarding: echo 1 > /proc/sys/net/ipv4/ip_forward"
echo "   5. Teste conectividade básica: ping 8.8.8.8"
echo "   6. Reinicie a rotação: ./ip_rotation_script.sh start"
echo

echo "   Para diagnosticar problemas:"
echo "   1. Execute: ./ip_rotation_script.sh diagnose"
echo "   2. Verifique os logs: tail -f /var/log/ip_rotation.log"
echo "   3. Teste cada IP individualmente: ping -I IP_PUBLICO 8.8.8.8"
echo

# 9. Script de correção automática
echo "7. Executar correção automática? (y/n)"
read -r response
if [[ "$response" =~ ^[Yy]$ ]]; then
    echo "   Executando correção automática..."
    
    # Parar rotação
    ./ip_rotation_script.sh stop 2>/dev/null
    
    # Limpar regras
    iptables -F
    iptables -t nat -F
    iptables -t mangle -F
    
    # Políticas permissivas
    iptables -P INPUT ACCEPT
    iptables -P FORWARD ACCEPT
    iptables -P OUTPUT ACCEPT
    
    # Habilitar forwarding
    echo 1 > /proc/sys/net/ipv4/ip_forward
    
    echo "   ✓ Correção automática concluída"
    echo "   Teste a conectividade básica e depois reinicie a rotação"
    echo "   Comandos: ping 8.8.8.8 && ./ip_rotation_script.sh start"
else
    echo "   Correção automática cancelada"
fi

echo
echo "=== FIM DO DEBUG ==="
