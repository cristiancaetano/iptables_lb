#!/bin/bash

# Script para testar rotação de IPs em tráfego roteado (FORWARD)
# Específico para tráfego de uma rede interna para a internet

INTERFACE="enp0s3"
PUBLIC_IPS=(
    "192.168.3.201"
    "192.168.3.202"
    "192.168.3.203"
    "192.168.3.200"
)

echo "=== Teste de Rotação para Tráfego Roteado (FORWARD) ==="
echo "Interface: $INTERFACE"
echo "IPs públicos: ${PUBLIC_IPS[*]}"
echo

# Verificar se IP forwarding está habilitado
echo "1. Verificando IP forwarding..."
FORWARD_STATUS=$(cat /proc/sys/net/ipv4/ip_forward)
if [ "$FORWARD_STATUS" = "1" ]; then
    echo "   ✓ IP forwarding está habilitado"
else
    echo "   ❌ IP forwarding está desabilitado"
    echo "   Habilitando IP forwarding..."
    sudo sysctl -w net.ipv4.ip_forward=1
fi

# Verificar chains
echo
echo "2. Verificando chains de marcação..."
if sudo iptables -t mangle -L IP_ROTATION_MARK -n >/dev/null 2>&1; then
    echo "   ✓ Chain IP_ROTATION_MARK existe"
    MARK_REFS=$(sudo iptables -t mangle -L IP_ROTATION_MARK -n | grep -o "[0-9]* references" | cut -d' ' -f1)
    echo "   Referências: $MARK_REFS"
else
    echo "   ❌ Chain IP_ROTATION_MARK não existe"
fi

# Verificar onde a chain está conectada
echo
echo "3. Verificando conexões da chain..."
echo "   PREROUTING:"
sudo iptables -t mangle -L PREROUTING -n --line-numbers | grep IP_ROTATION_MARK | head -2

echo "   FORWARD:"
sudo iptables -t mangle -L FORWARD -n --line-numbers | grep IP_ROTATION_MARK | head -2

# Verificar regras POSTROUTING
echo
echo "4. Verificando regras POSTROUTING..."
sudo iptables -t nat -L POSTROUTING -n --line-numbers | grep -E "(IP_ROTATION|MASQUERADE)" | head -5

# Resetar contadores
echo
echo "5. Resetando contadores..."
sudo iptables -t mangle -Z IP_ROTATION_MARK 2>/dev/null || true
sudo iptables -t nat -Z IP_ROTATION 2>/dev/null || true

# Simular tráfego roteado
echo
echo "6. Simulando tráfego roteado..."
echo "   Enviando pacotes de teste..."

# Enviar alguns pacotes
for i in {1..20}; do
    ping -c 1 -W 1 8.8.8.8 >/dev/null 2>&1 &
    sleep 0.1
done

# Aguardar conclusão
wait
sleep 2

# Verificar contadores
echo
echo "7. Verificando contadores após teste..."
echo "   Marcação (mangle):"
sudo iptables -t mangle -L IP_ROTATION_MARK -n -v | grep -E "(pkts|MARK)" | head -5

echo "   NAT (SNAT):"
sudo iptables -t nat -L IP_ROTATION -n -v | grep -E "(pkts|SNAT)" | head -5

echo "   Contadores por IP:"
for ((i=1; i<=${#PUBLIC_IPS[@]}; i++)); do
    local ip="${PUBLIC_IPS[$((i-1))]}"
    local count=$(sudo iptables -t nat -L IP_ROTATION -n -v | grep "mark match 0x$i" | awk '{print $1}' || echo "0")
    echo "   IP $ip (mark $i): $count pacotes"
done

# Verificar se há regras MASQUERADE conflitantes
echo
echo "8. Verificando regras MASQUERADE conflitantes..."
MASQ_RULES=$(sudo iptables -t nat -L POSTROUTING -n --line-numbers | grep -E "$INTERFACE.*MASQUERADE")
if [ -n "$MASQ_RULES" ]; then
    echo "   ⚠️  Regras MASQUERADE encontradas:"
    echo "$MASQ_RULES" | sed 's/^/   /'
    echo "   Isso pode estar causando conflitos!"
else
    echo "   ✓ Nenhuma regra MASQUERADE conflitante"
fi

# Diagnóstico
echo
echo "9. Diagnóstico:"
if [ "$MARK_REFS" = "0" ]; then
    echo "   ❌ PROBLEMA: Chain de marcação não está sendo chamada"
    echo "      Solução: Verificar se as regras PREROUTING/FORWARD foram criadas"
fi

if [ -n "$MASQ_RULES" ]; then
    echo "   ❌ PROBLEMA: Regras MASQUERADE estão interceptando o tráfego"
    echo "      Solução: Executar ./force_fix_ip_rotation.sh"
fi

# Sugestões
echo
echo "10. Próximos passos:"
echo "    - Se os contadores estão baixos: sudo ./force_fix_ip_rotation.sh"
echo "    - Para monitorar: ./test_ip_distribution.sh monitor"
echo "    - Para debug: sudo ./ip_rotation_script.sh debug"
