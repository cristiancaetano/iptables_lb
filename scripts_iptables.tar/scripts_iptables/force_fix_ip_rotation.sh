#!/bin/bash

# Script para forçar correção da rotação de IPs
# Implementa uma solução mais direta e agressiva

INTERFACE="enp0s3"
PUBLIC_IPS=(
    "192.168.3.201"
    "192.168.3.202"
    "192.168.3.203"
    "192.168.3.200"
)

echo "=== Correção Forçada de Rotação de IPs ==="

# Parar rotação atual
echo "1. Parando rotação atual..."
sudo /home/cristian/portainer/ip_rotation_script.sh stop 2>/dev/null || true

# Aguardar
sleep 2

# Limpar TODAS as regras MASQUERADE na interface
echo "2. Removendo TODAS as regras MASQUERADE na interface $INTERFACE..."
while sudo iptables -t nat -D POSTROUTING -o "$INTERFACE" -j MASQUERADE 2>/dev/null; do
    echo "   Removida regra MASQUERADE"
done

# Remover regras específicas
sudo iptables -t nat -D POSTROUTING -s 192.168.0.0/16 -o "$INTERFACE" -j MASQUERADE 2>/dev/null || true
sudo iptables -t nat -D POSTROUTING -s 10.0.0.0/8 -o "$INTERFACE" -j MASQUERADE 2>/dev/null || true
sudo iptables -t nat -D POSTROUTING -s 172.16.0.0/12 -o "$INTERFACE" -j MASQUERADE 2>/dev/null || true

# Mostrar estado atual
echo "3. Estado atual da chain POSTROUTING:"
sudo iptables -t nat -L POSTROUTING -n --line-numbers | grep -E "(^Chain|^num|$INTERFACE)"

# Criar regras manualmente
echo "4. Criando regras manualmente..."

# Criar chains
sudo iptables -t mangle -N IP_ROTATION_MARK_FORCE 2>/dev/null || true
sudo iptables -t nat -N IP_ROTATION_FORCE 2>/dev/null || true

# Limpar chains
sudo iptables -t mangle -F IP_ROTATION_MARK_FORCE
sudo iptables -t nat -F IP_ROTATION_FORCE

# Criar regras de marcação
num_ips=${#PUBLIC_IPS[@]}
for ((i=0; i<num_ips; i++)); do
    sudo iptables -t mangle -A IP_ROTATION_MARK_FORCE -m statistic --mode nth --every $num_ips --packet $i -j MARK --set-mark $((i+1))
done

# Criar regras de SNAT
for ((i=0; i<num_ips; i++)); do
    local ip="${PUBLIC_IPS[i]}"
    sudo iptables -t nat -A IP_ROTATION_FORCE -m mark --mark $((i+1)) -j SNAT --to-source "$ip"
done

# Conectar as chains com prioridade máxima - PARA TRÁFEGO ROTEADO
sudo iptables -t mangle -I PREROUTING 1 -j IP_ROTATION_MARK_FORCE
sudo iptables -t mangle -I FORWARD 1 -j IP_ROTATION_MARK_FORCE
sudo iptables -t nat -I POSTROUTING 1 -o "$INTERFACE" -j IP_ROTATION_FORCE

echo "5. Verificando configuração:"
echo "   Regras de marcação (PREROUTING):"
sudo iptables -t mangle -L PREROUTING -n --line-numbers | head -3

echo "   Regras de marcação (FORWARD):"
sudo iptables -t mangle -L FORWARD -n --line-numbers | head -3

echo "   Regras de NAT:"
sudo iptables -t nat -L IP_ROTATION_FORCE -n -v | head -6

echo "   Primeiras regras POSTROUTING:"
sudo iptables -t nat -L POSTROUTING -n --line-numbers | head -5

echo "6. Testando com ping..."
ping -c 4 8.8.8.8 >/dev/null 2>&1

echo "7. Estatísticas após teste:"
sudo iptables -t mangle -L IP_ROTATION_MARK_FORCE -n -v | grep -E "(pkts|MARK)"
sudo iptables -t nat -L IP_ROTATION_FORCE -n -v | grep -E "(pkts|SNAT)"

echo
echo "=== Correção Aplicada ==="
echo "Teste agora com: ./test_ip_distribution.sh test 10"
echo "Monitore com: ./test_ip_distribution.sh monitor"
