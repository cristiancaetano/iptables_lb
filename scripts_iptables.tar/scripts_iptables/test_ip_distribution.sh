#!/bin/bash

# Script para testar distribuição de IPs
# Simula múltiplas conexões e verifica a distribuição

INTERFACE="enp0s3"
PUBLIC_IPS=(
    "192.168.3.201"
    "192.168.3.202"
    "192.168.3.203"
    "192.168.3.200"
)

# Função para testar distribuição
test_distribution() {
    local num_tests=${1:-100}
    local target_host=${2:-"8.8.8.8"}
    
    echo "Testando distribuição com $num_tests conexões..."
    echo "Target: $target_host"
    echo "IPs públicos: ${PUBLIC_IPS[*]}"
    echo
    
    # Contador para cada IP
    declare -A ip_counts
    for ip in "${PUBLIC_IPS[@]}"; do
        ip_counts[$ip]=0
    done
    
    # Fazer conexões de teste
    for ((i=1; i<=num_tests; i++)); do
        # Simular conexão e capturar IP de saída
        local source_ip=$(curl -s --max-time 3 --interface "$INTERFACE" "http://ipinfo.io/ip" 2>/dev/null)
        
        if [[ -n "$source_ip" ]]; then
            for ip in "${PUBLIC_IPS[@]}"; do
                if [[ "$source_ip" == "$ip" ]]; then
                    ((ip_counts[$ip]++))
                    break
                fi
            done
        fi
        
        # Mostrar progresso
        if (( i % 10 == 0 )); then
            echo -n "."
        fi
        
        # Pequeno delay para evitar sobrecarga
        sleep 0.1
    done
    
    echo
    echo
    echo "=== Resultados da Distribuição ==="
    
    local total_successful=0
    for ip in "${PUBLIC_IPS[@]}"; do
        local count=${ip_counts[$ip]}
        local percentage=$(( count * 100 / num_tests ))
        total_successful=$((total_successful + count))
        
        echo "IP $ip: $count conexões (${percentage}%)"
    done
    
    echo
    echo "Total de conexões bem-sucedidas: $total_successful/$num_tests"
    echo "Taxa de sucesso: $(( total_successful * 100 / num_tests ))%"
    
    # Verificar se a distribuição está equilibrada
    local expected_per_ip=$(( num_tests / ${#PUBLIC_IPS[@]} ))
    local tolerance=10 # 10% de tolerância
    
    echo
    echo "=== Análise da Distribuição ==="
    echo "Esperado por IP: ~$expected_per_ip conexões"
    echo "Tolerância: ±$tolerance%"
    
    local balanced=true
    for ip in "${PUBLIC_IPS[@]}"; do
        local count=${ip_counts[$ip]}
        local diff=$(( count - expected_per_ip ))
        local diff_percent=$(( diff * 100 / expected_per_ip ))
        
        if (( diff_percent > tolerance || diff_percent < -tolerance )); then
            balanced=false
            echo "⚠️  IP $ip: Desvio de ${diff_percent}% (${diff:+${diff}}) - FORA DA TOLERÂNCIA"
        else
            echo "✅ IP $ip: Desvio de ${diff_percent}% (${diff:+${diff}}) - OK"
        fi
    done
    
    echo
    if $balanced; then
        echo "✅ Distribuição EQUILIBRADA"
    else
        echo "❌ Distribuição DESEQUILIBRADA - Execute 'sudo ip-rotation rebalance'"
    fi
}

# Função para testar estatísticas do iptables
test_iptables_stats() {
    echo "=== Estatísticas do iptables ==="
    
    echo "Regras de marcação (mangle):"
    iptables -t mangle -L IP_ROTATION_MARK -n -v --line-numbers 2>/dev/null | head -20
    
    echo
    echo "Regras de NAT:"
    iptables -t nat -L IP_ROTATION -n -v --line-numbers 2>/dev/null | head -20
    
    echo
    echo "Contadores por IP:"
    for ((i=1; i<=${#PUBLIC_IPS[@]}; i++)); do
        local ip="${PUBLIC_IPS[$((i-1))]}"
        local count=$(iptables -t nat -L IP_ROTATION -n -v | grep "mark match 0x$i" | awk '{print $1}' || echo "0")
        echo "IP $ip (mark $i): $count pacotes"
    done
}

# Função para resetar contadores
reset_counters() {
    echo "Resetando contadores do iptables..."
    iptables -t mangle -Z IP_ROTATION_MARK 2>/dev/null || true
    iptables -t nat -Z IP_ROTATION 2>/dev/null || true
    echo "Contadores resetados."
}

# Função para monitorar em tempo real
monitor_realtime() {
    echo "Monitorando distribuição em tempo real (Ctrl+C para parar)..."
    echo "Atualização a cada 5 segundos"
    echo
    
    while true; do
        clear
        echo "=== Monitor de Distribuição - $(date) ==="
        test_iptables_stats
        sleep 5
    done
}

# Função de ajuda
show_help() {
    cat << EOF
Uso: $0 [OPÇÃO] [PARÂMETROS]

Opções:
  test [NUM] [HOST]    Testar distribuição com NUM conexões (padrão: 100)
  stats               Mostrar estatísticas do iptables
  reset               Resetar contadores
  monitor             Monitorar em tempo real
  help                Mostrar esta ajuda

Exemplos:
  $0 test 50          Testar com 50 conexões
  $0 test 100 1.1.1.1 Testar com 100 conexões para 1.1.1.1
  $0 stats            Mostrar estatísticas
  $0 reset            Resetar contadores
  $0 monitor          Monitorar em tempo real

EOF
}

# Função principal
main() {
    local action="${1:-test}"
    
    case "$action" in
        test)
            test_distribution "${2:-100}" "${3:-8.8.8.8}"
            ;;
        stats)
            test_iptables_stats
            ;;
        reset)
            reset_counters
            ;;
        monitor)
            monitor_realtime
            ;;
        help|--help|-h)
            show_help
            ;;
        *)
            echo "Opção inválida: $action"
            show_help
            exit 1
            ;;
    esac
}

# Executar
main "$@"
