#!/bin/bash

# Script para configurar rotação de IPs públicos com iptables
# Autor: Sistema de Rotação de IPs
# Data: $(date)

# Configurações
INTERFACE="enp0s3"  # Interface de rede principal
LOG_FILE="/var/log/ip_rotation.log"
LOCK_FILE="/var/run/ip_rotation.lock"

# Array de IPs públicos - CONFIGURE AQUI SEUS IPs
PUBLIC_IPS=(
    "192.168.3.201"
    "192.168.3.202"
    "192.168.3.203"
    "192.168.3.200"
)

# Função para logging
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Função para verificar se o script já está rodando
check_lock() {
    if [ -f "$LOCK_FILE" ]; then
        local pid=$(cat "$LOCK_FILE")
        if ps -p "$pid" > /dev/null 2>&1; then
            log "ERRO: Script já está em execução (PID: $pid)"
            exit 1
        else
            log "AVISO: Lock file órfão removido"
            rm -f "$LOCK_FILE"
        fi
    fi
    echo $$ > "$LOCK_FILE"
}

# Função para limpeza na saída
cleanup() {
    rm -f "$LOCK_FILE"
    log "Script finalizado"
}

# Função para verificar se é root
check_root() {
    if [ "$EUID" -ne 0 ]; then
        echo "Este script deve ser executado como root"
        exit 1
    fi
}

# Função para verificar dependências
check_dependencies() {
    local deps=("iptables" "ip" "ping")
    for dep in "${deps[@]}"; do
        if ! command -v "$dep" &> /dev/null; then
            log "ERRO: Dependência '$dep' não encontrada"
            exit 1
        fi
    done
}

# Função para validar IPs
validate_ips() {
    local valid_ip_regex="^([0-9]{1,3}\.){3}[0-9]{1,3}$"
    
    for ip in "${PUBLIC_IPS[@]}"; do
        if [[ ! $ip =~ $valid_ip_regex ]]; then
            log "ERRO: IP inválido: $ip"
            exit 1
        fi
        
        # Verificar se cada octeto está entre 0-255
        IFS='.' read -r -a octets <<< "$ip"
        for octet in "${octets[@]}"; do
            if [ "$octet" -lt 0 ] || [ "$octet" -gt 255 ]; then
                log "ERRO: IP inválido: $ip (octeto fora do range)"
                exit 1
            fi
        done
    done
}

# Função para adicionar IPs à interface
configure_interface() {
    log "Configurando interface $INTERFACE com IPs públicos..."
    
    local primary_ip="${PUBLIC_IPS[0]}"
    local secondary_ips=("${PUBLIC_IPS[@]:1}")
    
    # Configurar IP principal
    ip addr add "$primary_ip/24" dev "$INTERFACE" 2>/dev/null || {
        log "AVISO: IP principal $primary_ip já configurado ou erro na configuração"
    }
    
    # Configurar IPs secundários
    for ip in "${secondary_ips[@]}"; do
        ip addr add "$ip/24" dev "$INTERFACE" 2>/dev/null || {
            log "AVISO: IP secundário $ip já configurado ou erro na configuração"
        }
    done
    
    log "Configuração de interface concluída"
}

# Função para limpar regras existentes
clear_rules() {
    log "Limpando regras de iptables existentes..."
    
    # Limpar chains personalizadas se existirem
    iptables -t nat -F IP_ROTATION 2>/dev/null || true
    iptables -t nat -X IP_ROTATION 2>/dev/null || true
    iptables -t mangle -F IP_ROTATION_MARK 2>/dev/null || true
    iptables -t mangle -X IP_ROTATION_MARK 2>/dev/null || true
    
    # Remover regras da chain POSTROUTING que referenciam nossa chain
    iptables -t nat -D POSTROUTING -o "$INTERFACE" -j IP_ROTATION 2>/dev/null || true
    iptables -t mangle -D PREROUTING -j IP_ROTATION_MARK 2>/dev/null || true
    iptables -t mangle -D FORWARD -j IP_ROTATION_MARK 2>/dev/null || true
    iptables -t mangle -D OUTPUT -j IP_ROTATION_MARK 2>/dev/null || true
    
    # Remover TODAS as regras MASQUERADE na interface de forma agressiva
    while iptables -t nat -D POSTROUTING -o "$INTERFACE" -j MASQUERADE 2>/dev/null; do
        log "Removendo regra MASQUERADE existente..."
    done
    
    # Remover regras específicas de sub-redes
    iptables -t nat -D POSTROUTING -s 192.168.0.0/16 -o "$INTERFACE" -j MASQUERADE 2>/dev/null || true
    iptables -t nat -D POSTROUTING -s 10.0.0.0/8 -o "$INTERFACE" -j MASQUERADE 2>/dev/null || true
    iptables -t nat -D POSTROUTING -s 172.16.0.0/12 -o "$INTERFACE" -j MASQUERADE 2>/dev/null || true
    
    # Garantir que as políticas básicas não sejam restritivas
    iptables -P INPUT ACCEPT
    iptables -P FORWARD ACCEPT
    iptables -P OUTPUT ACCEPT
    
    log "Limpeza concluída"
}

# Função para criar regras de rotação
create_rotation_rules() {
    log "Criando regras de rotação de IPs..."
    
    local num_ips=${#PUBLIC_IPS[@]}
    
    # Habilitar IP forwarding
    echo 1 > /proc/sys/net/ipv4/ip_forward
    
    # Criar chain para marcação de pacotes
    iptables -t mangle -N IP_ROTATION_MARK
    
    # Criar chain para NAT
    iptables -t nat -N IP_ROTATION
    
    # Permitir tráfego de entrada relacionado e estabelecido
    iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
    iptables -A INPUT -i lo -j ACCEPT
    
    # Permitir forwarding para conexões estabelecidas
    iptables -A FORWARD -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
    iptables -A FORWARD -i lo -j ACCEPT
    
    # Permitir tráfego de saída da rede local
    iptables -A FORWARD -s 10.0.0.0/8 -j ACCEPT
    iptables -A FORWARD -s 172.16.0.0/12 -j ACCEPT
    iptables -A FORWARD -s 192.168.0.0/16 -j ACCEPT
    
    # Marcar pacotes para rotação - usando método melhorado para distribuição
    # Aplicar marcação apenas para tráfego que será roteado (não local)
    for ((i=0; i<num_ips; i++)); do
        if [ $i -eq $((num_ips-1)) ]; then
            # Última regra pega todos os pacotes restantes
            iptables -t mangle -A IP_ROTATION_MARK -j MARK --set-mark $((i+1))
        else
            # Usar nth packet para distribuição mais uniforme
            iptables -t mangle -A IP_ROTATION_MARK -m statistic --mode nth --every $num_ips --packet $i -j MARK --set-mark $((i+1))
        fi
    done
    
    # Aplicar SNAT baseado na marcação - apenas para tráfego de saída
    for ((i=0; i<num_ips; i++)); do
        local ip="${PUBLIC_IPS[i]}"
        iptables -t nat -A IP_ROTATION -m mark --mark $((i+1)) -j SNAT --to-source "$ip"
    done
    
    # Remover regra MASQUERADE da nossa chain (será tratada externamente)
    # iptables -t nat -A IP_ROTATION -j MASQUERADE
    
    # Conectar as chains às chains principais - PARA TRÁFEGO ROTEADO (FORWARD)
    # Marcar pacotes no PREROUTING (antes do roteamento)
    iptables -t mangle -I PREROUTING 1 -j IP_ROTATION_MARK
    
    # Também marcar no FORWARD para garantir (tráfego roteado)
    iptables -t mangle -I FORWARD 1 -j IP_ROTATION_MARK
    
    # Aplicar NAT como primeira regra na interface de saída
    iptables -t nat -I POSTROUTING 1 -o "$INTERFACE" -j IP_ROTATION
    
    # Remover TODAS as regras MASQUERADE existentes na interface
    while iptables -t nat -D POSTROUTING -o "$INTERFACE" -j MASQUERADE 2>/dev/null; do
        log "Removendo regra MASQUERADE conflitante..."
    done
    
    # Adicionar MASQUERADE apenas para pacotes não marcados (como backup)
    iptables -t nat -A POSTROUTING -o "$INTERFACE" -m mark --mark 0 -j MASQUERADE
    
    # Otimizar distribuição
    optimize_distribution
    
    log "Regras de rotação criadas com sucesso"
}

# Função para testar conectividade
test_connectivity() {
    log "Testando conectividade dos IPs públicos..."
    
    for ip in "${PUBLIC_IPS[@]}"; do
        if ping -c 1 -W 5 -I "$ip" 8.8.8.8 > /dev/null 2>&1; then
            log "✓ IP $ip: Conectividade OK"
        else
            log "✗ IP $ip: Falha na conectividade"
        fi
    done
}

# Função para diagnóstico de problemas
diagnose_connectivity() {
    log "=== Diagnóstico de Conectividade ==="
    
    # Verificar IP forwarding
    local forward_status=$(cat /proc/sys/net/ipv4/ip_forward)
    log "IP Forwarding: $forward_status (deve ser 1)"
    
    # Verificar interfaces
    log "Interfaces ativas:"
    ip addr show "$INTERFACE" | grep -E "inet|UP|DOWN" | sed 's/^/  /'
    
    # Verificar rotas
    log "Tabela de rotas:"
    ip route show | sed 's/^/  /'
    
    # Verificar regras de iptables
    log "Regras NAT:"
    iptables -t nat -L -n -v | sed 's/^/  /'
    
    log "Regras MANGLE:"
    iptables -t mangle -L -n -v | sed 's/^/  /'
    
    log "Regras FILTER:"
    iptables -L -n -v | sed 's/^/  /'
    
    # Teste de conectividade interna
    log "Testando conectividade interna..."
    if ping -c 1 -W 5 127.0.0.1 > /dev/null 2>&1; then
        log "✓ Localhost: OK"
    else
        log "✗ Localhost: Falha"
    fi
    
    # Teste de conectividade externa
    log "Testando conectividade externa..."
    if ping -c 1 -W 5 8.8.8.8 > /dev/null 2>&1; then
        log "✓ Internet: OK"
    else
        log "✗ Internet: Falha"
    fi
}

# Função para mostrar estatísticas
show_stats() {
    log "=== Estatísticas de Rotação ==="
    
    echo "IPs configurados:"
    for ((i=0; i<${#PUBLIC_IPS[@]}; i++)); do
        echo "  $((i+1)). ${PUBLIC_IPS[i]}"
    done
    
    echo
    echo "Regras de NAT ativas:"
    iptables -t nat -L IP_ROTATION -n -v 2>/dev/null || echo "Nenhuma regra encontrada"
    
    echo
    echo "Regras de marcação ativas:"
    iptables -t mangle -L IP_ROTATION_MARK -n -v 2>/dev/null || echo "Nenhuma regra encontrada"
}

# Função para backup das regras
backup_rules() {
    local backup_file="/etc/iptables/ip_rotation_backup_$(date +%Y%m%d_%H%M%S).rules"
    mkdir -p /etc/iptables
    
    iptables-save > "$backup_file"
    log "Backup das regras salvo em: $backup_file"
}

# Função para restaurar regras
restore_rules() {
    local backup_file="$1"
    
    if [ -f "$backup_file" ]; then
        iptables-restore < "$backup_file"
        log "Regras restauradas de: $backup_file"
    else
        log "ERRO: Arquivo de backup não encontrado: $backup_file"
        exit 1
    fi
}

# Função para monitoramento contínuo
monitor_rotation() {
    log "Iniciando monitoramento de rotação..."
    
    while true; do
        # Verificar se as regras ainda existem
        if ! iptables -t nat -L IP_ROTATION > /dev/null 2>&1; then
            log "AVISO: Regras de rotação perdidas, recriando..."
            create_rotation_rules
        fi
        
        # Mostrar estatísticas a cada 5 minutos
        if [ $(($(date +%s) % 300)) -eq 0 ]; then
            show_stats
        fi
        
        sleep 60
    done
}

# Função para otimizar distribuição de pacotes
optimize_distribution() {
    log "Otimizando distribuição de pacotes..."
    
    local num_ips=${#PUBLIC_IPS[@]}
    
    # Limpar regras antigas de marcação
    iptables -t mangle -F IP_ROTATION_MARK 2>/dev/null || true
    
    # Criar regras otimizadas baseadas no método configurado
    case "${ROTATION_METHOD:-random}" in
        "round-robin")
            # Método round-robin mais eficiente usando nth
            for ((i=0; i<num_ips; i++)); do
                iptables -t mangle -A IP_ROTATION_MARK -m statistic --mode nth --every $num_ips --packet $i -j MARK --set-mark $((i+1))
            done
            log "Rotação round-robin configurada"
            ;;
            
        "weighted")
            # Método weighted usando probabilidades
            local total_weight=0
            for weight in "${ROTATION_WEIGHTS[@]}"; do
                total_weight=$((total_weight + weight))
            done
            
            for ((i=0; i<num_ips; i++)); do
                local weight=${ROTATION_WEIGHTS[i]:-10}
                local probability=$(echo "scale=10; $weight / $total_weight" | bc -l)
                
                if [ $i -eq $((num_ips-1)) ]; then
                    iptables -t mangle -A IP_ROTATION_MARK -j MARK --set-mark $((i+1))
                else
                    iptables -t mangle -A IP_ROTATION_MARK -m statistic --mode random --probability "$probability" -j MARK --set-mark $((i+1))
                fi
            done
            log "Rotação weighted configurada"
            ;;
            
        "hash")
            # Método hash para distribuição consistente baseada em IP origem
            for ((i=0; i<num_ips; i++)); do
                iptables -t mangle -A IP_ROTATION_MARK -m statistic --mode random --probability "0.25" -j MARK --set-mark $((i+1))
            done
            log "Rotação hash configurada"
            ;;
            
        *)
            # Método padrão otimizado (nth packet)
            for ((i=0; i<num_ips; i++)); do
                iptables -t mangle -A IP_ROTATION_MARK -m statistic --mode nth --every $num_ips --packet $i -j MARK --set-mark $((i+1))
            done
            log "Rotação padrão (nth packet) configurada"
            ;;
    esac
}

# Função para rebalancear distribuição
rebalance() {
    log "Rebalanceando distribuição de IPs..."
    
    if ! iptables -t mangle -L IP_ROTATION_MARK > /dev/null 2>&1; then
        log "ERRO: Rotação não está ativa"
        exit 1
    fi
    
    # Mostrar estatísticas antes
    log "Estatísticas antes do rebalanceamento:"
    show_stats
    
    # Otimizar distribuição
    optimize_distribution
    
    # Resetar contadores
    iptables -t mangle -Z IP_ROTATION_MARK 2>/dev/null || true
    iptables -t nat -Z IP_ROTATION 2>/dev/null || true
    
    log "Rebalanceamento concluído"
}

# Função para debug detalhado
debug_detailed() {
    log "=== DEBUG DETALHADO ==="
    
    # Verificar todas as regras POSTROUTING
    log "Todas as regras POSTROUTING:"
    iptables -t nat -L POSTROUTING -n --line-numbers | sed 's/^/  /'
    
    # Verificar todas as regras PREROUTING (mangle)
    log "Todas as regras PREROUTING (mangle):"
    iptables -t mangle -L PREROUTING -n --line-numbers | sed 's/^/  /'
    
    # Verificar todas as regras FORWARD (mangle)
    log "Todas as regras FORWARD (mangle):"
    iptables -t mangle -L FORWARD -n --line-numbers | sed 's/^/  /'
    
    # Verificar se há regras MASQUERADE conflitantes
    log "Verificando regras MASQUERADE na interface $INTERFACE:"
    iptables -t nat -L POSTROUTING -n --line-numbers | grep -E "$INTERFACE.*MASQUERADE" | sed 's/^/  CONFLITO: /'
    
    # Testar um ping e verificar contadores
    log "Testando ping e verificando contadores..."
    ping -c 1 8.8.8.8 >/dev/null 2>&1
    
    log "Contadores após ping:"
    iptables -t mangle -L IP_ROTATION_MARK -n -v | grep -E "(pkts|MARK)" | sed 's/^/  /'
    iptables -t nat -L IP_ROTATION -n -v | grep -E "(pkts|SNAT)" | sed 's/^/  /'
    
    # Verificar se os IPs estão configurados na interface
    log "IPs configurados na interface $INTERFACE:"
    ip addr show "$INTERFACE" | grep -E "inet " | sed 's/^/  /'
}

# Função para exibir ajuda
show_help() {
    cat << EOF
Uso: $0 [OPÇÃO]

Opções:
  start           Iniciar rotação de IPs
  stop            Parar rotação de IPs
  restart         Reiniciar rotação de IPs
  status          Mostrar status atual
  rebalance       Rebalancear distribuição de IPs
  test            Testar conectividade
  diagnose        Diagnóstico completo de conectividade
  debug           Debug detalhado das regras
  monitor         Monitorar rotação continuamente
  backup          Fazer backup das regras
  restore FILE    Restaurar regras do backup
  help            Mostrar esta ajuda

Configuração:
  - Edite o array PUBLIC_IPS no início do script
  - Ajuste a variável INTERFACE conforme necessário
  - Execute como root

Exemplos:
  $0 start
  $0 status
  $0 diagnose
  $0 backup
  $0 restore /etc/iptables/backup.rules

EOF
}

# Função principal
main() {
    local action="${1:-start}"
    
    trap cleanup EXIT INT TERM
    
    case "$action" in
        start)
            check_root
            check_dependencies
            validate_ips
            check_lock
            
            log "=== Iniciando Rotação de IPs ==="
            log "Interface: $INTERFACE"
            log "IPs públicos: ${PUBLIC_IPS[*]}"
            
            backup_rules
            configure_interface
            clear_rules
            create_rotation_rules
            test_connectivity
            show_stats
            
            log "=== Rotação de IPs configurada com sucesso ==="
            ;;
            
        stop)
            check_root
            log "=== Parando Rotação de IPs ==="
            clear_rules
            log "=== Rotação de IPs parada ==="
            ;;
            
        restart)
            $0 stop
            sleep 2
            $0 start
            ;;
            
        status)
            show_stats
            ;;
            
        test)
            check_dependencies
            validate_ips
            test_connectivity
            ;;
            
        diagnose)
            check_dependencies
            validate_ips
            diagnose_connectivity
            ;;
            
        debug)
            check_dependencies
            validate_ips
            debug_detailed
            ;;
            
        monitor)
            check_root
            check_dependencies
            validate_ips
            monitor_rotation
            ;;
            
        backup)
            check_root
            backup_rules
            ;;
            
        restore)
            check_root
            restore_rules "$2"
            ;;
            
        rebalance)
            check_root
            check_dependencies
            validate_ips
            rebalance
            ;;
            
        help|--help|-h)
            show_help
            ;;
            
        *)
            echo "Opção inválida: $action"
            show_help
            exit 1
            ;;
    esac
}

# Executar função principal
main "$@"
