#!/bin/bash

# Script para corrigir problemas de rotação de IPs
# Aplica correções específicas para garantir que a marcação funcione

INTERFACE="eth0"
PUBLIC_IPS=(
    "192.168.3.201"
    "192.168.3.202"
    "192.168.3.203"
    "192.168.3.200"
)

echo "=== Corrigindo Rotação de IPs ==="

# Parar o serviço atual
echo "1. Parando rotação atual..."
sudo /home/cristian/portainer/ip_rotation_script.sh stop 2>/dev/null || true

# Limpar todas as regras MASQUERADE na interface
echo "2. Limpando regras MASQUERADE conflitantes..."
sudo iptables -t nat -D POSTROUTING -o "$INTERFACE" -j MASQUERADE 2>/dev/null || true
sudo iptables -t nat -D POSTROUTING -s 192.168.0.0/16 -o "$INTERFACE" -j MASQUERADE 2>/dev/null || true
sudo iptables -t nat -D POSTROUTING -s 10.0.0.0/8 -o "$INTERFACE" -j MASQUERADE 2>/dev/null || true
sudo iptables -t nat -D POSTROUTING -s 172.16.0.0/12 -o "$INTERFACE" -j MASQUERADE 2>/dev/null || true

# Mostrar regras atuais
echo "3. Regras POSTROUTING atuais:"
sudo iptables -t nat -L POSTROUTING -n --line-numbers

# Reiniciar rotação
echo "4. Reiniciando rotação com correções..."
sudo /home/cristian/portainer/ip_rotation_script.sh start

# Verificar se está funcionando
echo "5. Verificando funcionamento..."
sleep 2
echo "Estatísticas após correção:"
sudo iptables -t nat -L IP_ROTATION -n -v
echo
sudo iptables -t mangle -L IP_ROTATION_MARK -n -v

echo "=== Correção concluída ==="
echo "Para testar, execute: ./test_ip_distribution.sh test 20"

# Verificar se as regras foram aplicadas
echo "3. Verificando regras aplicadas..."
echo
echo "=== Regras de marcação (mangle) ==="
sudo iptables -t mangle -L OUTPUT -n -v | grep IP_ROTATION_MARK
echo
echo "=== Regras de NAT ==="
sudo iptables -t nat -L POSTROUTING -n -v | grep IP_ROTATION
echo
echo "=== Estatísticas das chains ==="
sudo iptables -t mangle -L IP_ROTATION_MARK -n -v
echo
sudo iptables -t nat -L IP_ROTATION -n -v

echo
echo "4. Testando conectividade..."
sudo /home/cristian/portainer/ip_rotation_script.sh test

echo
echo "=== Correções aplicadas! ==="
echo "Agora teste com: sudo /home/cristian/portainer/test_ip_distribution.sh test 20"
