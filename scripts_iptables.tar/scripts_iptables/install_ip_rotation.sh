#!/bin/bash

# Script de Instalação para Rotação de IPs
# Instala e configura o sistema de rotação de IPs públicos

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="/usr/local/bin"
CONFIG_DIR="/etc"
SERVICE_DIR="/etc/systemd/system"

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Função para logging colorido
log() {
    local level="$1"
    shift
    local message="$*"
    
    case "$level" in
        "INFO")
            echo -e "${GREEN}[INFO]${NC} $message"
            ;;
        "WARN")
            echo -e "${YELLOW}[WARN]${NC} $message"
            ;;
        "ERROR")
            echo -e "${RED}[ERROR]${NC} $message"
            ;;
        *)
            echo "[LOG] $message"
            ;;
    esac
}

# Verificar se é root
check_root() {
    if [ "$EUID" -ne 0 ]; then
        log "ERROR" "Este script deve ser executado como root"
        exit 1
    fi
}

# Verificar dependências
check_dependencies() {
    local deps=("iptables" "ip" "bc" "systemctl")
    local missing=()
    
    for dep in "${deps[@]}"; do
        if ! command -v "$dep" &> /dev/null; then
            missing+=("$dep")
        fi
    done
    
    if [ ${#missing[@]} -gt 0 ]; then
        log "ERROR" "Dependências não encontradas: ${missing[*]}"
        log "INFO" "Instalando dependências..."
        
        # Detectar distribuição e instalar dependências
        if command -v apt-get &> /dev/null; then
            apt-get update
            apt-get install -y iptables iproute2 bc systemd
        elif command -v yum &> /dev/null; then
            yum install -y iptables iproute bc systemd
        elif command -v dnf &> /dev/null; then
            dnf install -y iptables iproute bc systemd
        else
            log "ERROR" "Sistema de pacotes não suportado"
            exit 1
        fi
    fi
}

# Criar diretórios necessários
create_directories() {
    log "INFO" "Criando diretórios necessários..."
    
    mkdir -p /var/log
    mkdir -p /etc/iptables
    mkdir -p /usr/local/bin
    mkdir -p /etc/systemd/system
}

# Instalar arquivos
install_files() {
    log "INFO" "Instalando arquivos do sistema..."
    
    # Copiar script principal
    if [ -f "$SCRIPT_DIR/ip_rotation_script.sh" ]; then
        cp "$SCRIPT_DIR/ip_rotation_script.sh" "$INSTALL_DIR/ip-rotation"
        chmod +x "$INSTALL_DIR/ip-rotation"
        log "INFO" "Script principal instalado em $INSTALL_DIR/ip-rotation"
    else
        log "ERROR" "Arquivo ip_rotation_script.sh não encontrado"
        exit 1
    fi
    
    # Copiar arquivo de configuração
    if [ -f "$SCRIPT_DIR/ip_rotation.conf" ]; then
        if [ ! -f "$CONFIG_DIR/ip_rotation.conf" ]; then
            cp "$SCRIPT_DIR/ip_rotation.conf" "$CONFIG_DIR/"
            log "INFO" "Arquivo de configuração instalado em $CONFIG_DIR/ip_rotation.conf"
        else
            log "WARN" "Arquivo de configuração já existe, não sobrescrevendo"
        fi
    fi
}

# Criar serviço systemd
create_service() {
    log "INFO" "Criando serviço systemd..."
    
    cat > "$SERVICE_DIR/ip-rotation.service" << EOF
[Unit]
Description=IP Rotation Service
Documentation=man:ip-rotation
After=network.target
Wants=network.target

[Service]
Type=forking
ExecStart=$INSTALL_DIR/ip-rotation start
ExecStop=$INSTALL_DIR/ip-rotation stop
ExecReload=$INSTALL_DIR/ip-rotation restart
Restart=on-failure
RestartSec=10
User=root
Group=root

# Configurações de segurança
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/log /etc/iptables /proc /sys
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    log "INFO" "Serviço systemd criado"
}

# Configurar logrotate
setup_logrotate() {
    log "INFO" "Configurando logrotate..."
    
    cat > /etc/logrotate.d/ip-rotation << EOF
/var/log/ip_rotation.log {
    daily
    rotate 30
    compress
    delaycompress
    missingok
    notifempty
    create 644 root root
    postrotate
        /usr/bin/systemctl reload ip-rotation > /dev/null 2>&1 || true
    endscript
}
EOF
}

# Configurar firewall básico
setup_firewall() {
    log "INFO" "Configurando regras básicas de firewall..."
    
    # Permitir tráfego loopback
    iptables -A INPUT -i lo -j ACCEPT
    iptables -A OUTPUT -o lo -j ACCEPT
    
    # Permitir conexões estabelecidas
    iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
    
    # Permitir SSH (porta 22)
    iptables -A INPUT -p tcp --dport 22 -j ACCEPT
    
    # Salvar regras
    if command -v iptables-save &> /dev/null; then
        iptables-save > /etc/iptables/rules.v4
    fi
}

# Exibir informações pós-instalação
post_install_info() {
    log "INFO" "Instalação concluída com sucesso!"
    echo
    echo "Próximos passos:"
    echo "1. Edite o arquivo de configuração: /etc/ip_rotation.conf"
    echo "2. Configure seus IPs públicos no array PUBLIC_IPS"
    echo "3. Inicie o serviço: systemctl start ip-rotation"
    echo "4. Habilite na inicialização: systemctl enable ip-rotation"
    echo
    echo "Comandos úteis:"
    echo "  ip-rotation start     - Iniciar rotação"
    echo "  ip-rotation stop      - Parar rotação"
    echo "  ip-rotation status    - Ver status"
    echo "  ip-rotation test      - Testar conectividade"
    echo "  ip-rotation monitor   - Monitorar em tempo real"
    echo
    echo "Logs: /var/log/ip_rotation.log"
    echo "Configuração: /etc/ip_rotation.conf"
    echo "Serviço: systemctl status ip-rotation"
}

# Desinstalar
uninstall() {
    log "INFO" "Desinstalando sistema de rotação de IPs..."
    
    # Parar serviço
    systemctl stop ip-rotation 2>/dev/null || true
    systemctl disable ip-rotation 2>/dev/null || true
    
    # Remover arquivos
    rm -f "$INSTALL_DIR/ip-rotation"
    rm -f "$SERVICE_DIR/ip-rotation.service"
    rm -f "/etc/logrotate.d/ip-rotation"
    
    # Limpar regras do iptables
    "$INSTALL_DIR/ip-rotation" stop 2>/dev/null || true
    
    systemctl daemon-reload
    
    log "INFO" "Desinstalação concluída"
    log "WARN" "Arquivo de configuração mantido em /etc/ip_rotation.conf"
}

# Função principal
main() {
    local action="${1:-install}"
    
    case "$action" in
        install)
            check_root
            check_dependencies
            create_directories
            install_files
            create_service
            setup_logrotate
            setup_firewall
            post_install_info
            ;;
            
        uninstall)
            check_root
            uninstall
            ;;
            
        *)
            echo "Uso: $0 [install|uninstall]"
            exit 1
            ;;
    esac
}

# Executar
main "$@"
